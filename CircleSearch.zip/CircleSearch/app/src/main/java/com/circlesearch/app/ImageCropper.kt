package com.circlesearch.app

import android.graphics.Bitmap
import android.graphics.Rect
import java.io.File

object ImageCropper {

    /** Crops [rect] (in bitmap pixel coordinates) out of [src]. The rect is clamped to the bitmap. */
    fun crop(src: Bitmap, rect: Rect): Bitmap {
        val left = rect.left.coerceIn(0, src.width - 1)
        val top = rect.top.coerceIn(0, src.height - 1)
        val right = rect.right.coerceIn(left + 1, src.width)
        val bottom = rect.bottom.coerceIn(top + 1, src.height)
        return Bitmap.createBitmap(src, left, top, right - left, bottom - top)
    }

    fun saveJpeg(bitmap: Bitmap, file: File, quality: Int = 95) {
        file.parentFile?.mkdirs()
        file.outputStream().use { out ->
            bitmap.compress(Bitmap.CompressFormat.JPEG, quality, out)
        }
    }
}

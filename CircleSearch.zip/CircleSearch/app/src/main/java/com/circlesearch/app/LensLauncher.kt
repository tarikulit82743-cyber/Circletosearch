package com.circlesearch.app

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.core.content.FileProvider
import java.io.File

/**
 * Sends the cropped image to Google Lens.
 *
 * Google does not publish a stable "open Lens with this image" intent. What we do instead:
 *  1. Try a normal ACTION_SEND (image) aimed directly at the Google app (and the old
 *     standalone Lens app). The Google app registers a share target that opens Lens.
 *  2. If that is not available, or "always use share sheet" is on, show Android's share sheet
 *     so the user can pick Google / Lens / Photos.
 */
object LensLauncher {

    private val DIRECT_PACKAGES = listOf(
        "com.google.android.googlequicksearchbox",
        "com.google.ar.lens"
    )

    fun launch(activity: Activity, file: File) {
        val uri = FileProvider.getUriForFile(
            activity, "${activity.packageName}.fileprovider", file
        )

        if (!Prefs.alwaysShareSheet(activity)) {
            for (pkg in DIRECT_PACKAGES) {
                val intent = buildSendIntent(uri).setPackage(pkg)
                if (intent.resolveActivity(activity.packageManager) == null) continue
                try {
                    activity.startActivity(intent)
                    return
                } catch (e: ActivityNotFoundException) {
                    // try the next option
                } catch (e: SecurityException) {
                    // try the next option
                }
            }
        }

        val chooser = Intent.createChooser(buildSendIntent(uri), activity.getString(R.string.share_title))
        chooser.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        try {
            activity.startActivity(chooser)
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(activity, R.string.toast_no_app, Toast.LENGTH_LONG).show()
        }
    }

    private fun buildSendIntent(uri: Uri): Intent =
        Intent(Intent.ACTION_SEND).apply {
            type = "image/jpeg"
            putExtra(Intent.EXTRA_STREAM, uri)
            clipData = ClipData.newRawUri("CircleSearch selection", uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
}

package com.circlesearch.app

import android.accessibilityservice.AccessibilityButtonController
import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.media.AudioManager
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent
import android.widget.Toast

/**
 * Detects the user's shortcut and starts CircleSearch.
 *
 * Privacy: this service does NOT declare canRetrieveWindowContent and subscribes to no
 * accessibility events, so it cannot read anything on screen. It only receives
 *  - clicks of the system accessibility button / shortcut, and
 *  - the single volume key the user chose in Settings (to detect a long press).
 */
class CircleAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: CircleAccessibilityService? = null
            private set
    }

    private val handler = Handler(Looper.getMainLooper())
    private var holdFired = false
    private var lastTriggerAt = 0L

    private val holdRunnable = Runnable {
        holdFired = true
        trigger()
    }

    private val buttonCallback = object : AccessibilityButtonController.AccessibilityButtonCallback() {
        override fun onClicked(controller: AccessibilityButtonController) {
            trigger()
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        try {
            accessibilityButtonController.registerAccessibilityButtonCallback(buttonCallback)
        } catch (e: Exception) {
            // Accessibility button not available on this device; volume shortcut still works.
        }
    }

    override fun onUnbind(intent: Intent?): Boolean {
        cleanup()
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        cleanup()
        super.onDestroy()
    }

    private fun cleanup() {
        handler.removeCallbacks(holdRunnable)
        try {
            accessibilityButtonController.unregisterAccessibilityButtonCallback(buttonCallback)
        } catch (e: Exception) {
            // already unregistered
        }
        if (instance === this) instance = null
    }

    // Required by the AccessibilityService contract. We intentionally ignore all events.
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Intentionally empty: CircleSearch does not read screen content.
    }

    override fun onInterrupt() {
        handler.removeCallbacks(holdRunnable)
    }

    // ---------------------------------------------------------------- volume-key shortcut

    override fun onKeyEvent(event: KeyEvent): Boolean {
        val wantedKey = when (Prefs.shortcutMode(this)) {
            Prefs.SHORTCUT_HOLD_VOLUME_DOWN -> KeyEvent.KEYCODE_VOLUME_DOWN
            Prefs.SHORTCUT_HOLD_VOLUME_UP -> KeyEvent.KEYCODE_VOLUME_UP
            else -> return false
        }
        if (event.keyCode != wantedKey) return false
        // Do not hijack the volume key unless a capture session is running.
        if (!CaptureService.isRunning) return false

        when (event.action) {
            KeyEvent.ACTION_DOWN -> {
                if (event.repeatCount == 0) {
                    holdFired = false
                    handler.removeCallbacks(holdRunnable)
                    handler.postDelayed(holdRunnable, Prefs.holdMs(this).toLong())
                }
            }
            KeyEvent.ACTION_UP -> {
                handler.removeCallbacks(holdRunnable)
                // A short tap should still change the volume as usual.
                if (!holdFired) adjustVolume(wantedKey)
            }
        }
        return true
    }

    private fun adjustVolume(keyCode: Int) {
        val direction = if (keyCode == KeyEvent.KEYCODE_VOLUME_UP) {
            AudioManager.ADJUST_RAISE
        } else {
            AudioManager.ADJUST_LOWER
        }
        getSystemService(AudioManager::class.java).adjustSuggestedStreamVolume(
            direction,
            AudioManager.USE_DEFAULT_STREAM_TYPE,
            AudioManager.FLAG_SHOW_UI
        )
    }

    // ---------------------------------------------------------------- trigger

    private fun trigger() {
        val now = SystemClock.elapsedRealtime()
        if (now - lastTriggerAt < 1200) return
        lastTriggerAt = now

        if (!CaptureService.isRunning) {
            Toast.makeText(this, R.string.toast_session_not_running, Toast.LENGTH_LONG).show()
            return
        }
        CaptureCoordinator.captureAndOpen(this)
    }
}

package com.circlesearch.app

import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.util.Size
import android.view.WindowManager
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.core.content.IntentCompat
import java.io.File
import java.util.concurrent.Executors

/**
 * Foreground service (type mediaProjection) that owns the MediaProjection granted by the user
 * through the official system dialog. It keeps the newest screen frame in memory and turns it
 * into a screenshot ONLY when the user triggers CircleSearch.
 *
 * Nothing is sent anywhere. The screenshot is written to the app's private cache.
 */
class CaptureService : Service() {

    companion object {
        const val ACTION_START = "com.circlesearch.app.action.START"
        const val ACTION_STOP = "com.circlesearch.app.action.STOP"
        private const val EXTRA_RESULT_CODE = "result_code"
        private const val EXTRA_RESULT_DATA = "result_data"
        private const val CHANNEL_ID = "capture_session"
        private const val NOTIFICATION_ID = 1001
        private const val FRAME_TIMEOUT_MS = 1500L

        @Volatile
        var instance: CaptureService? = null
            private set

        /** Called on the main thread whenever the session starts or stops. */
        var stateListener: (() -> Unit)? = null

        val isRunning: Boolean
            get() = instance?.ready == true

        fun start(context: Context, resultCode: Int, data: Intent) {
            val intent = Intent(context, CaptureService::class.java)
                .setAction(ACTION_START)
                .putExtra(EXTRA_RESULT_CODE, resultCode)
                .putExtra(EXTRA_RESULT_DATA, data)
            ContextCompat.startForegroundService(context, intent)
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, CaptureService::class.java))
        }
    }

    @Volatile
    var ready = false
        private set

    private val mainHandler = Handler(Looper.getMainLooper())
    private val ioExecutor = Executors.newSingleThreadExecutor()

    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var latestImage: Image? = null
    private var shuttingDown = false

    private val projectionCallback = object : MediaProjection.Callback() {
        override fun onStop() {
            // The user (or the system) ended screen capture.
            shutdown()
            stopSelf()
        }
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                shutdown()
                stopSelf()
            }
            ACTION_START -> handleStart(intent)
            else -> if (!ready) stopSelf()
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        shutdown()
        instance = null
        ioExecutor.shutdown()
        stateListener?.invoke()
        super.onDestroy()
    }

    // ---------------------------------------------------------------- start / stop

    private fun handleStart(intent: Intent) {
        createChannel()
        // Android 14: must call startForeground with the mediaProjection type BEFORE getMediaProjection().
        startForeground(
            NOTIFICATION_ID,
            buildNotification(),
            ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
        )
        if (ready) return

        val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED)
        val data = IntentCompat.getParcelableExtra(intent, EXTRA_RESULT_DATA, Intent::class.java)
        if (resultCode != Activity.RESULT_OK || data == null || !startProjection(resultCode, data)) {
            shutdown()
            stopSelf()
        }
    }

    private fun startProjection(resultCode: Int, data: Intent): Boolean {
        return try {
            val manager = getSystemService(MediaProjectionManager::class.java)
            val newProjection = manager.getMediaProjection(resultCode, data) ?: return false
            projection = newProjection
            // Android 14 requires a callback to be registered before creating the VirtualDisplay.
            newProjection.registerCallback(projectionCallback, mainHandler)
            buildDisplay(currentSize())
            ready = true
            stateListener?.invoke()
            true
        } catch (e: Exception) {
            false
        }
    }

    private fun shutdown() {
        if (shuttingDown) return
        shuttingDown = true
        ready = false
        latestImage?.close()
        latestImage = null
        virtualDisplay?.release()
        virtualDisplay = null
        imageReader?.close()
        imageReader = null
        projection?.let {
            try {
                it.unregisterCallback(projectionCallback)
                it.stop()
            } catch (e: Exception) {
                // already stopped
            }
        }
        projection = null
        TempFiles.deleteAll(applicationContext)
        stateListener?.invoke()
    }

    // ---------------------------------------------------------------- display + frames

    private fun currentSize(): Size {
        val bounds = getSystemService(WindowManager::class.java).maximumWindowMetrics.bounds
        return Size(bounds.width(), bounds.height())
    }

    private fun createReader(width: Int, height: Int): ImageReader {
        val reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 3)
        reader.setOnImageAvailableListener({ r ->
            try {
                val image = r.acquireLatestImage()
                if (image != null) {
                    latestImage?.close()
                    latestImage = image
                }
            } catch (e: IllegalStateException) {
                // reader was closed or too many images; ignore this frame
            }
        }, mainHandler)
        return reader
    }

    private fun buildDisplay(size: Size) {
        val reader = createReader(size.width, size.height)
        imageReader = reader
        virtualDisplay = projection!!.createVirtualDisplay(
            "CircleSearchDisplay",
            size.width,
            size.height,
            resources.displayMetrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader.surface,
            null,
            mainHandler
        )
    }

    /** If the phone was rotated, resize the virtual display to match. */
    private fun ensureSize() {
        val size = currentSize()
        val oldReader = imageReader ?: return
        if (oldReader.width == size.width && oldReader.height == size.height) return
        val display = virtualDisplay ?: return
        latestImage?.close()
        latestImage = null
        val newReader = createReader(size.width, size.height)
        display.resize(size.width, size.height, resources.displayMetrics.densityDpi)
        display.surface = newReader.surface
        imageReader = newReader
        oldReader.close()
    }

    /**
     * Saves the newest frame as the screenshot file and reports it on the main thread.
     * Must be called on the main thread.
     */
    fun capture(callback: (File?) -> Unit) {
        if (!ready) {
            callback(null)
            return
        }
        ensureSize()
        waitForFrame(SystemClock.uptimeMillis() + FRAME_TIMEOUT_MS, callback)
    }

    private fun waitForFrame(deadline: Long, callback: (File?) -> Unit) {
        if (!ready) {
            callback(null)
            return
        }
        val image = latestImage
        if (image != null) {
            val bitmap = try {
                imageToBitmap(image)
            } catch (e: Exception) {
                null
            }
            if (bitmap == null) {
                callback(null)
                return
            }
            val target = TempFiles.screenshotFile(applicationContext)
            ioExecutor.execute {
                val ok = try {
                    ImageCropper.saveJpeg(bitmap, target)
                    true
                } catch (e: Exception) {
                    false
                }
                bitmap.recycle()
                mainHandler.post { callback(if (ok) target else null) }
            }
        } else if (SystemClock.uptimeMillis() < deadline) {
            mainHandler.postDelayed({ waitForFrame(deadline, callback) }, 40)
        } else {
            callback(null)
        }
    }

    private fun imageToBitmap(image: Image): Bitmap {
        val plane = image.planes[0]
        val buffer = plane.buffer
        buffer.rewind()
        val pixelStride = plane.pixelStride
        val rowPadding = plane.rowStride - pixelStride * image.width
        val padded = Bitmap.createBitmap(
            image.width + rowPadding / pixelStride,
            image.height,
            Bitmap.Config.ARGB_8888
        )
        padded.copyPixelsFromBuffer(buffer)
        val result = if (rowPadding == 0) {
            padded
        } else {
            val cropped = Bitmap.createBitmap(padded, 0, 0, image.width, image.height)
            padded.recycle()
            cropped
        }
        result.setHasAlpha(false)
        return result
    }

    // ---------------------------------------------------------------- notification

    private fun createChannel() {
        val channel = NotificationChannel(
            CHANNEL_ID,
            getString(R.string.notif_channel_name),
            NotificationManager.IMPORTANCE_LOW
        )
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }

    private fun buildNotification(): Notification {
        val openIntent = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stopIntent = PendingIntent.getService(
            this, 1,
            Intent(this, CaptureService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(getString(R.string.notif_title))
            .setContentText(getString(R.string.notif_text))
            .setContentIntent(openIntent)
            .addAction(0, getString(R.string.notif_stop), stopIntent)
            .setOngoing(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)
            .build()
    }
}

package com.circlesearch.app

import android.content.Context
import java.io.File

/** All temporary images live in the app's private cache folder and are deleted after use. */
object TempFiles {

    private const val DIR = "shots"
    private const val SCREENSHOT = "screenshot.jpg"
    private const val CROP_PREFIX = "crop_"

    fun dir(context: Context): File {
        val d = File(context.cacheDir, DIR)
        if (!d.exists()) d.mkdirs()
        return d
    }

    fun screenshotFile(context: Context): File = File(dir(context), SCREENSHOT)

    fun newCropFile(context: Context): File =
        File(dir(context), "$CROP_PREFIX${System.currentTimeMillis()}.jpg")

    fun deleteScreenshot(context: Context) {
        screenshotFile(context).delete()
    }

    /** Deletes crops older than [olderThanMs] (use 0 to delete every crop). */
    fun deleteOldCrops(context: Context, olderThanMs: Long) {
        val now = System.currentTimeMillis()
        dir(context).listFiles()?.forEach { f ->
            if (f.name.startsWith(CROP_PREFIX) && now - f.lastModified() >= olderThanMs) {
                f.delete()
            }
        }
    }

    fun deleteAll(context: Context) {
        dir(context).listFiles()?.forEach { it.delete() }
    }
}

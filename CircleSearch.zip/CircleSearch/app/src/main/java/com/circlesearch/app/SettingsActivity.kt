package com.circlesearch.app

import android.os.Bundle
import android.widget.RadioGroup
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton
import com.google.android.material.button.MaterialButtonToggleGroup
import com.google.android.material.materialswitch.MaterialSwitch
import com.google.android.material.slider.Slider

class SettingsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        // Volume-key shortcut
        val radio = findViewById<RadioGroup>(R.id.radioShortcut)
        radio.check(
            when (Prefs.shortcutMode(this)) {
                Prefs.SHORTCUT_HOLD_VOLUME_DOWN -> R.id.rbHoldDown
                Prefs.SHORTCUT_HOLD_VOLUME_UP -> R.id.rbHoldUp
                else -> R.id.rbOff
            }
        )
        radio.setOnCheckedChangeListener { _, checkedId ->
            Prefs.setShortcutMode(
                this,
                when (checkedId) {
                    R.id.rbHoldDown -> Prefs.SHORTCUT_HOLD_VOLUME_DOWN
                    R.id.rbHoldUp -> Prefs.SHORTCUT_HOLD_VOLUME_UP
                    else -> Prefs.SHORTCUT_OFF
                }
            )
        }

        // Hold time
        val holdLabel = findViewById<TextView>(R.id.tvHoldTime)
        val slider = findViewById<Slider>(R.id.sliderHold)
        val savedHold = ((Prefs.holdMs(this) + 50) / 100) * 100
        slider.value = savedHold.coerceIn(300, 1500).toFloat()
        holdLabel.text = getString(R.string.settings_hold_time, slider.value.toInt())
        slider.addOnChangeListener { _, value, _ ->
            Prefs.setHoldMs(this, value.toInt())
            holdLabel.text = getString(R.string.settings_hold_time, value.toInt())
        }

        // Default shape
        val shapeGroup = findViewById<MaterialButtonToggleGroup>(R.id.toggleShape)
        shapeGroup.check(if (Prefs.defaultCircle(this)) R.id.btnShapeCircle else R.id.btnShapeRect)
        shapeGroup.addOnButtonCheckedListener { _, checkedId, isChecked ->
            if (isChecked) Prefs.setDefaultCircle(this, checkedId == R.id.btnShapeCircle)
        }

        // Switches
        val switchVibrate = findViewById<MaterialSwitch>(R.id.switchVibrate)
        switchVibrate.isChecked = Prefs.vibrate(this)
        switchVibrate.setOnCheckedChangeListener { _, checked -> Prefs.setVibrate(this, checked) }

        val switchShare = findViewById<MaterialSwitch>(R.id.switchShareSheet)
        switchShare.isChecked = Prefs.alwaysShareSheet(this)
        switchShare.setOnCheckedChangeListener { _, checked -> Prefs.setAlwaysShareSheet(this, checked) }

        // Delete temp files
        findViewById<MaterialButton>(R.id.btnDeleteTemp).setOnClickListener {
            TempFiles.deleteAll(this)
            Toast.makeText(this, R.string.toast_cleared, Toast.LENGTH_SHORT).show()
        }
    }
}

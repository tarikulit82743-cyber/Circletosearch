package com.circlesearch.app

import android.content.Context
import android.content.Intent
import android.os.VibrationEffect
import android.os.Vibrator
import android.widget.Toast

/**
 * Glue between "the user triggered CircleSearch" and "the selection screen is showing".
 * Must be called on the main thread.
 */
object CaptureCoordinator {

    private var busy = false

    fun captureAndOpen(context: Context) {
        val appContext = context.applicationContext
        val service = CaptureService.instance
        if (service == null || !service.ready) {
            Toast.makeText(appContext, R.string.toast_session_not_running, Toast.LENGTH_LONG).show()
            return
        }
        if (busy) return
        busy = true

        TempFiles.deleteOldCrops(appContext, 10 * 60 * 1000L)

        service.capture { file ->
            busy = false
            if (file == null) {
                Toast.makeText(appContext, R.string.toast_capture_failed, Toast.LENGTH_LONG).show()
                return@capture
            }
            vibrate(appContext)

            // The accessibility service is allowed to start activities from the background.
            val launchContext: Context = CircleAccessibilityService.instance ?: appContext
            val intent = Intent(launchContext, SelectionActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            launchContext.startActivity(intent)
        }
    }

    private fun vibrate(context: Context) {
        if (!Prefs.vibrate(context)) return
        val vibrator = context.getSystemService(Vibrator::class.java) ?: return
        vibrator.vibrate(VibrationEffect.createOneShot(25, VibrationEffect.DEFAULT_AMPLITUDE))
    }
}

package com.circlesearch.app

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.content.Intent
import android.os.Bundle
import android.view.WindowManager
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.google.android.material.button.MaterialButton
import com.google.android.material.button.MaterialButtonToggleGroup
import java.util.concurrent.Executors

/** Full-screen selection screen: shows the screenshot, lets the user select, crops, opens Lens. */
class SelectionActivity : AppCompatActivity() {

    private lateinit var selectionView: SelectionView
    private lateinit var hint: TextView
    private lateinit var btnSearch: MaterialButton
    private val executor = Executors.newSingleThreadExecutor()
    private var screenshot: Bitmap? = null
    private var searching = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enterImmersiveMode()
        setContentView(R.layout.activity_selection)

        selectionView = findViewById(R.id.selectionView)
        hint = findViewById(R.id.tvHint)
        btnSearch = findViewById(R.id.btnSearch)
        val btnCancel = findViewById<MaterialButton>(R.id.btnCancel)
        val toggle = findViewById<MaterialButtonToggleGroup>(R.id.toggleMode)

        val startCircle = Prefs.defaultCircle(this)
        selectionView.mode = if (startCircle) SelectionView.Mode.CIRCLE else SelectionView.Mode.RECTANGLE
        toggle.check(if (startCircle) R.id.btnModeCircle else R.id.btnModeRect)
        updateHint(false)

        toggle.addOnButtonCheckedListener { _, checkedId, isChecked ->
            if (isChecked) {
                selectionView.mode =
                    if (checkedId == R.id.btnModeRect) SelectionView.Mode.RECTANGLE
                    else SelectionView.Mode.CIRCLE
                updateHint(btnSearch.isEnabled)
            }
        }

        selectionView.onSelectionChanged = { has ->
            btnSearch.isEnabled = has
            updateHint(has)
        }

        btnCancel.setOnClickListener { finish() }
        btnSearch.setOnClickListener { onSearchClicked() }

        loadScreenshot()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        searching = false
        loadScreenshot()
    }

    override fun onStop() {
        super.onStop()
        // The selection screen is transient. If the user leaves it, close it and clean up.
        if (!isChangingConfigurations) finish()
    }

    override fun onDestroy() {
        if (isFinishing) TempFiles.deleteScreenshot(this)
        executor.shutdown()
        super.onDestroy()
    }

    private fun enterImmersiveMode() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        val params = window.attributes
        params.layoutInDisplayCutoutMode =
            WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        window.attributes = params
        val controller = WindowInsetsControllerCompat(window, window.decorView)
        controller.hide(WindowInsetsCompat.Type.systemBars())
        controller.systemBarsBehavior =
            WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
    }

    private fun updateHint(hasSelection: Boolean) {
        hint.setText(
            when {
                hasSelection -> R.string.hint_adjust
                selectionView.mode == SelectionView.Mode.RECTANGLE -> R.string.hint_draw_rect
                else -> R.string.hint_draw_circle
            }
        )
    }

    private fun loadScreenshot() {
        val file = TempFiles.screenshotFile(this)
        val bitmap = if (file.exists()) BitmapFactory.decodeFile(file.absolutePath) else null
        if (bitmap == null) {
            Toast.makeText(this, R.string.toast_no_screenshot, Toast.LENGTH_LONG).show()
            finish()
            return
        }
        screenshot = bitmap
        selectionView.setBitmap(bitmap)
        btnSearch.isEnabled = false
        updateHint(false)
    }

    private fun onSearchClicked() {
        if (searching) return
        val source = screenshot ?: return
        val rect = selectionView.getSelectionInBitmap() ?: return
        searching = true
        btnSearch.isEnabled = false

        executor.execute {
            val cropFile = try {
                val cropped = ImageCropper.crop(source, rect)
                val target = TempFiles.newCropFile(this)
                ImageCropper.saveJpeg(cropped, target)
                cropped.recycle()
                target
            } catch (e: Exception) {
                null
            }

            runOnUiThread {
                if (isFinishing || isDestroyed) return@runOnUiThread
                if (cropFile == null) {
                    Toast.makeText(this, R.string.toast_crop_failed, Toast.LENGTH_LONG).show()
                    searching = false
                    btnSearch.isEnabled = true
                    return@runOnUiThread
                }
                LensLauncher.launch(this, cropFile)
                finish()
            }
        }
    }
}

package com.circlesearch.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Rect
import android.graphics.RectF
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Shows the screenshot and lets the user select an area with a finger.
 *
 *  - CIRCLE mode: draw any loop around the target; its bounding box becomes the selection.
 *  - RECTANGLE mode: drag a box.
 *
 * After drawing, the selection can be moved (drag inside it) or resized (drag a corner handle).
 * All maths is done in view coordinates and converted to bitmap pixels in [getSelectionInBitmap].
 */
class SelectionView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    enum class Mode { CIRCLE, RECTANGLE }

    private enum class Touch { NONE, DRAW, MOVE, RESIZE }

    var mode: Mode = Mode.CIRCLE
        set(value) {
            field = value
            invalidate()
        }

    /** Called with true when a selection exists, false when it was cleared. */
    var onSelectionChanged: ((Boolean) -> Unit)? = null

    private var bitmap: Bitmap? = null
    private val imageRect = RectF()
    private val selection = RectF()
    private var hasSelection = false

    private var touch = Touch.NONE
    private var activeCorner = -1
    private var lastX = 0f
    private var lastY = 0f
    private var startX = 0f
    private var startY = 0f
    private val strokePath = Path()
    private val strokeBounds = RectF()

    private val density = resources.displayMetrics.density
    private val handleRadius = 9f * density
    private val hitRadius = 30f * density
    private val minSize = 48f * density
    private val minDraw = 24f * density

    private val bitmapPaint = Paint(Paint.FILTER_BITMAP_FLAG)
    private val dimPaint = Paint().apply { color = 0xAA000000.toInt() }
    private val outlinePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 3f * density
        color = 0xFFFFFFFF.toInt()
    }
    private val guidePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 1f * density
        color = 0x80FFFFFF.toInt()
    }
    private val drawPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 6f * density
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        color = 0xFF8AB4F8.toInt()
    }
    private val handleFill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = 0xFFFFFFFF.toInt()
    }
    private val handleStroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 2f * density
        color = 0xFF1A73E8.toInt()
    }

    // ---------------------------------------------------------------- public API

    fun setBitmap(newBitmap: Bitmap) {
        bitmap = newBitmap
        setHasSelection(false)
        computeImageRect()
        invalidate()
    }

    /** The selection converted to pixel coordinates of the original screenshot, or null. */
    fun getSelectionInBitmap(): Rect? {
        val bmp = bitmap ?: return null
        if (!hasSelection || imageRect.width() <= 0f || imageRect.height() <= 0f) return null
        val scaleX = bmp.width / imageRect.width()
        val scaleY = bmp.height / imageRect.height()
        val left = ((selection.left - imageRect.left) * scaleX).roundToInt().coerceIn(0, bmp.width - 1)
        val top = ((selection.top - imageRect.top) * scaleY).roundToInt().coerceIn(0, bmp.height - 1)
        val right = ((selection.right - imageRect.left) * scaleX).roundToInt().coerceIn(left + 1, bmp.width)
        val bottom = ((selection.bottom - imageRect.top) * scaleY).roundToInt().coerceIn(top + 1, bmp.height)
        return Rect(left, top, right, bottom)
    }

    // ---------------------------------------------------------------- layout

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        computeImageRect()
        setHasSelection(false)
    }

    private fun computeImageRect() {
        val bmp = bitmap ?: return
        if (width == 0 || height == 0) return
        val scale = min(width.toFloat() / bmp.width, height.toFloat() / bmp.height)
        val drawWidth = bmp.width * scale
        val drawHeight = bmp.height * scale
        val left = (width - drawWidth) / 2f
        val top = (height - drawHeight) / 2f
        imageRect.set(left, top, left + drawWidth, top + drawHeight)
    }

    // ---------------------------------------------------------------- drawing

    private fun shapePath(): Path {
        val path = Path()
        if (mode == Mode.CIRCLE) {
            path.addOval(selection, Path.Direction.CW)
        } else {
            path.addRoundRect(selection, 12f * density, 12f * density, Path.Direction.CW)
        }
        return path
    }

    private fun cornerX(i: Int): Float = if (i == 0 || i == 3) selection.left else selection.right
    private fun cornerY(i: Int): Float = if (i == 0 || i == 1) selection.top else selection.bottom

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val bmp = bitmap ?: return
        canvas.drawBitmap(bmp, null, imageRect, bitmapPaint)

        val previewingRect = touch == Touch.DRAW && mode == Mode.RECTANGLE
        if (hasSelection || previewingRect) {
            val path = shapePath()
            canvas.save()
            canvas.clipOutPath(path)
            canvas.drawRect(imageRect, dimPaint)
            canvas.restore()
            canvas.drawPath(path, outlinePaint)

            if (hasSelection) {
                if (mode == Mode.CIRCLE) canvas.drawRect(selection, guidePaint)
                for (i in 0..3) {
                    canvas.drawCircle(cornerX(i), cornerY(i), handleRadius, handleFill)
                    canvas.drawCircle(cornerX(i), cornerY(i), handleRadius, handleStroke)
                }
            }
        }

        if (touch == Touch.DRAW && mode == Mode.CIRCLE) {
            canvas.drawPath(strokePath, drawPaint)
        }
    }

    // ---------------------------------------------------------------- touch

    private fun clampX(x: Float) = x.coerceIn(imageRect.left, imageRect.right)
    private fun clampY(y: Float) = y.coerceIn(imageRect.top, imageRect.bottom)

    private fun hitCorner(x: Float, y: Float): Int {
        var best = -1
        var bestDistance = hitRadius
        for (i in 0..3) {
            val d = hypot(x - cornerX(i), y - cornerY(i))
            if (d <= bestDistance) {
                bestDistance = d
                best = i
            }
        }
        return best
    }

    private fun setHasSelection(value: Boolean) {
        if (hasSelection != value) {
            hasSelection = value
            onSelectionChanged?.invoke(value)
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (bitmap == null || imageRect.isEmpty) return false
        val x = event.x
        val y = event.y

        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                lastX = x
                lastY = y
                val corner = if (hasSelection) hitCorner(x, y) else -1
                if (corner >= 0) {
                    touch = Touch.RESIZE
                    activeCorner = corner
                } else if (hasSelection && selection.contains(x, y)) {
                    touch = Touch.MOVE
                } else {
                    beginDraw(x, y)
                }
            }
            MotionEvent.ACTION_MOVE -> {
                when (touch) {
                    Touch.DRAW -> continueDraw(x, y)
                    Touch.MOVE -> moveSelection(x, y)
                    Touch.RESIZE -> resizeSelection(x, y)
                    Touch.NONE -> Unit
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> endTouch()
        }
        invalidate()
        return true
    }

    private fun beginDraw(x: Float, y: Float) {
        setHasSelection(false)
        touch = Touch.DRAW
        startX = clampX(x)
        startY = clampY(y)
        strokePath.reset()
        strokePath.moveTo(startX, startY)
        strokeBounds.set(startX, startY, startX, startY)
        selection.set(startX, startY, startX, startY)
    }

    private fun continueDraw(x: Float, y: Float) {
        val cx = clampX(x)
        val cy = clampY(y)
        if (mode == Mode.CIRCLE) {
            strokePath.lineTo(cx, cy)
            strokeBounds.union(cx, cy)
        } else {
            selection.set(min(startX, cx), min(startY, cy), max(startX, cx), max(startY, cy))
        }
    }

    private fun moveSelection(x: Float, y: Float) {
        var dx = x - lastX
        var dy = y - lastY
        dx = dx.coerceIn(imageRect.left - selection.left, imageRect.right - selection.right)
        dy = dy.coerceIn(imageRect.top - selection.top, imageRect.bottom - selection.bottom)
        selection.offset(dx, dy)
        lastX = x
        lastY = y
    }

    private fun resizeSelection(x: Float, y: Float) {
        val cx = clampX(x)
        val cy = clampY(y)
        when (activeCorner) {
            0 -> {
                selection.left = min(cx, selection.right - minSize)
                selection.top = min(cy, selection.bottom - minSize)
            }
            1 -> {
                selection.right = max(cx, selection.left + minSize)
                selection.top = min(cy, selection.bottom - minSize)
            }
            2 -> {
                selection.right = max(cx, selection.left + minSize)
                selection.bottom = max(cy, selection.top + minSize)
            }
            3 -> {
                selection.left = min(cx, selection.right - minSize)
                selection.bottom = max(cy, selection.top + minSize)
            }
        }
        selection.intersect(imageRect)
    }

    private fun endTouch() {
        if (touch == Touch.DRAW) {
            if (mode == Mode.CIRCLE) finishCircle() else finishRect()
            strokePath.reset()
        }
        touch = Touch.NONE
        activeCorner = -1
    }

    private fun finishCircle() {
        if (strokeBounds.width() < minDraw && strokeBounds.height() < minDraw) {
            setHasSelection(false)
            return
        }
        selection.set(strokeBounds)
        // small margin so the drawn line itself is not cut off
        selection.inset(-6f * density, -6f * density)
        if (selection.width() < minSize) selection.inset(-(minSize - selection.width()) / 2f, 0f)
        if (selection.height() < minSize) selection.inset(0f, -(minSize - selection.height()) / 2f)
        selection.intersect(imageRect)
        setHasSelection(true)
    }

    private fun finishRect() {
        if (selection.width() >= minDraw && selection.height() >= minDraw) {
            setHasSelection(true)
        } else {
            setHasSelection(false)
        }
    }
}

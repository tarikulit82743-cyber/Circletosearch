package com.circlesearch.app

import android.Manifest
import android.content.Intent
import android.media.projection.MediaProjectionConfig
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.android.material.button.MaterialButton

class MainActivity : AppCompatActivity() {

    private lateinit var tvSessionStatus: TextView
    private lateinit var btnToggle: MaterialButton
    private lateinit var tvGestureStatus: TextView
    private lateinit var tvGestureMethod: TextView
    private lateinit var tvPermAccessibility: TextView
    private lateinit var tvPermCapture: TextView
    private lateinit var tvPermNotif: TextView
    private lateinit var btnNotif: MaterialButton

    // Official system dialog that asks the user to allow screen capture.
    private val projectionLauncher =
        registerForActivityResult(androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult()) { result ->
            val data = result.data
            if (result.resultCode == RESULT_OK && data != null) {
                CaptureService.start(this, result.resultCode, data)
            } else {
                Toast.makeText(this, R.string.toast_denied, Toast.LENGTH_LONG).show()
            }
        }

    private val notificationLauncher =
        registerForActivityResult(androidx.activity.result.contract.ActivityResultContracts.RequestPermission()) {
            refresh()
            // Continue with the capture request whether or not notifications were allowed.
            if (!CaptureService.isRunning) requestProjection()
        }

    private val notificationOnlyLauncher =
        registerForActivityResult(androidx.activity.result.contract.ActivityResultContracts.RequestPermission()) {
            refresh()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvSessionStatus = findViewById(R.id.tvSessionStatus)
        btnToggle = findViewById(R.id.btnToggle)
        tvGestureStatus = findViewById(R.id.tvGestureStatus)
        tvGestureMethod = findViewById(R.id.tvGestureMethod)
        tvPermAccessibility = findViewById(R.id.tvPermAccessibility)
        tvPermCapture = findViewById(R.id.tvPermCapture)
        tvPermNotif = findViewById(R.id.tvPermNotif)
        btnNotif = findViewById(R.id.btnNotif)

        // Housekeeping: remove leftovers from earlier sessions.
        TempFiles.deleteScreenshot(this)
        TempFiles.deleteOldCrops(this, 10 * 60 * 1000L)

        btnToggle.setOnClickListener {
            if (CaptureService.isRunning) {
                CaptureService.stop(this)
            } else {
                startFlow()
            }
        }

        findViewById<MaterialButton>(R.id.btnOpenAccessibility).setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        findViewById<MaterialButton>(R.id.btnRestricted).setOnClickListener {
            startActivity(
                Intent(
                    Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    Uri.parse("package:$packageName")
                )
            )
        }

        btnNotif.setOnClickListener {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                notificationOnlyLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }

        findViewById<MaterialButton>(R.id.btnSettings).setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }

        findViewById<MaterialButton>(R.id.btnTry).setOnClickListener {
            if (!CaptureService.isRunning || !Permissions.isAccessibilityEnabled(this)) {
                Toast.makeText(this, R.string.toast_need_session_and_service, Toast.LENGTH_LONG).show()
            } else {
                Toast.makeText(this, R.string.toast_try_prepare, Toast.LENGTH_LONG).show()
                moveTaskToBack(true)
                Handler(Looper.getMainLooper()).postDelayed({
                    CaptureCoordinator.captureAndOpen(applicationContext)
                }, 3000)
            }
        }
    }

    override fun onStart() {
        super.onStart()
        CaptureService.stateListener = { refresh() }
        refresh()
    }

    override fun onStop() {
        super.onStop()
        CaptureService.stateListener = null
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun startFlow() {
        val needsNotifPermission = Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            !Permissions.notificationsGranted(this)
        if (needsNotifPermission) {
            notificationLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            requestProjection()
        }
    }

    private fun requestProjection() {
        val manager = getSystemService(MediaProjectionManager::class.java)
        val intent = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            // Android 14: ask for the whole screen (not just a single app window).
            manager.createScreenCaptureIntent(MediaProjectionConfig.createConfigForDefaultDisplay())
        } else {
            manager.createScreenCaptureIntent()
        }
        projectionLauncher.launch(intent)
    }

    private fun refresh() {
        val accessibilityOn = Permissions.isAccessibilityEnabled(this)
        val sessionActive = CaptureService.isRunning
        val notifOn = Permissions.notificationsGranted(this)

        tvSessionStatus.setText(if (sessionActive) R.string.status_session_active else R.string.status_session_inactive)
        tvSessionStatus.setTextColor(color(sessionActive))
        btnToggle.setText(if (sessionActive) R.string.btn_stop else R.string.btn_start)

        tvGestureStatus.setText(if (accessibilityOn) R.string.gesture_ready else R.string.gesture_needs_service)
        tvGestureStatus.setTextColor(color(accessibilityOn))
        tvGestureMethod.setText(
            when (Prefs.shortcutMode(this)) {
                Prefs.SHORTCUT_HOLD_VOLUME_DOWN -> R.string.method_hold_down
                Prefs.SHORTCUT_HOLD_VOLUME_UP -> R.string.method_hold_up
                else -> R.string.method_off
            }
        )

        tvPermAccessibility.setText(if (accessibilityOn) R.string.perm_accessibility_on else R.string.perm_accessibility_off)
        tvPermAccessibility.setTextColor(color(accessibilityOn))
        tvPermCapture.setText(if (sessionActive) R.string.perm_capture_on else R.string.perm_capture_off)
        tvPermCapture.setTextColor(color(sessionActive))
        tvPermNotif.setText(if (notifOn) R.string.perm_notif_on else R.string.perm_notif_off)
        tvPermNotif.setTextColor(color(notifOn))
        btnNotif.isEnabled = !notifOn
    }

    private fun color(ok: Boolean): Int =
        ContextCompat.getColor(this, if (ok) R.color.status_ok else R.color.status_bad)
}

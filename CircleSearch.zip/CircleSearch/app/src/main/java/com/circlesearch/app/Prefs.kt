package com.circlesearch.app

import android.content.Context

/** Tiny wrapper around SharedPreferences. Everything stays on the device. */
object Prefs {
    const val SHORTCUT_OFF = 0
    const val SHORTCUT_HOLD_VOLUME_DOWN = 1
    const val SHORTCUT_HOLD_VOLUME_UP = 2

    private const val FILE = "circlesearch_prefs"
    private const val KEY_SHORTCUT = "shortcut_mode"
    private const val KEY_HOLD_MS = "hold_ms"
    private const val KEY_DEFAULT_CIRCLE = "default_circle"
    private const val KEY_VIBRATE = "vibrate"
    private const val KEY_SHARE_SHEET = "always_share_sheet"

    private fun sp(context: Context) =
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    fun shortcutMode(context: Context): Int =
        sp(context).getInt(KEY_SHORTCUT, SHORTCUT_HOLD_VOLUME_DOWN)

    fun setShortcutMode(context: Context, value: Int) {
        sp(context).edit().putInt(KEY_SHORTCUT, value).apply()
    }

    fun holdMs(context: Context): Int =
        sp(context).getInt(KEY_HOLD_MS, 700).coerceIn(300, 1500)

    fun setHoldMs(context: Context, value: Int) {
        sp(context).edit().putInt(KEY_HOLD_MS, value).apply()
    }

    fun defaultCircle(context: Context): Boolean =
        sp(context).getBoolean(KEY_DEFAULT_CIRCLE, true)

    fun setDefaultCircle(context: Context, value: Boolean) {
        sp(context).edit().putBoolean(KEY_DEFAULT_CIRCLE, value).apply()
    }

    fun vibrate(context: Context): Boolean =
        sp(context).getBoolean(KEY_VIBRATE, true)

    fun setVibrate(context: Context, value: Boolean) {
        sp(context).edit().putBoolean(KEY_VIBRATE, value).apply()
    }

    fun alwaysShareSheet(context: Context): Boolean =
        sp(context).getBoolean(KEY_SHARE_SHEET, false)

    fun setAlwaysShareSheet(context: Context, value: Boolean) {
        sp(context).edit().putBoolean(KEY_SHARE_SHEET, value).apply()
    }
}

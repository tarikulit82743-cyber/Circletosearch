# CircleSearch

Circle anything on your screen, then search it with Google Lens.
Native Android (Kotlin). No floating bubble, no root, no account, no analytics, no INTERNET permission.

Target: Vivo Y03t, Android 14 (minSdk 30, targetSdk 34).

## How it works

1. You tap **Start CircleSearch** once. Android shows its official "Start recording or casting?" dialog.
   After you allow it, a foreground service (type `mediaProjection`) keeps the newest screen frame in memory.
2. You trigger CircleSearch with a shortcut (see below).
3. CircleSearch turns the newest frame into a screenshot (private cache folder) and opens the selection screen.
4. You draw a circle or box, adjust it, and tap **Search**.
5. The selection is cropped from the original screenshot and sent to Google Lens (share intent to the Google app),
   or to the Android share sheet as a fallback.
6. Temporary files are deleted when you leave, stop the session, or after 10 minutes.

## Honest limits (please read)

- **A global "hold" gesture is NOT possible for normal apps.** Long-pressing the Home button / navigation bar
  belongs to the system assistant (on Pixel/Samsung that is what runs Circle to Search). Android gives no API to take it over.
- What CircleSearch uses instead:
  1. **Accessibility button / shortcut** (system feature, works on Android 14).
  2. **Hold Volume Down (or Up)**, configurable in Settings. Works only while a capture session is running.
     A quick tap still changes the volume. Holding starts CircleSearch instead of repeating volume changes.
- **Android 14 asks for screen-capture permission every time you press Start.** There is no way around this and it is on purpose.
  After a reboot, or if the system ends the session, tap Start again.
- While a session runs, Android may show a screen-sharing indicator and a notification. That is normal and cannot be hidden.
- Apps that block screenshots (banking, some video apps) show a black image. That is Android protecting them.
- **There is no documented Google Lens intent.** The app sends the image to the Google app with a standard share intent
  and falls back to the share sheet. Depending on your Google app version, the direct route may open Lens or may do nothing
  useful. If so, turn on "Always use the share sheet" in Settings and pick Google / Lens there.
- The Vivo Y03t is a low-end phone. Keep the session stopped when you are not using it to save battery.

## Project structure

```
CircleSearch/
  settings.gradle.kts
  build.gradle.kts
  gradle.properties
  gradle/wrapper/gradle-wrapper.properties
  .github/workflows/build-apk.yml        (builds the APK online, no PC needed)
  app/
    build.gradle.kts
    proguard-rules.pro
    src/main/
      AndroidManifest.xml
      java/com/circlesearch/app/
        MainActivity.kt                  main screen
        SettingsActivity.kt              settings
        SelectionActivity.kt             selection screen + crop + Lens
        SelectionView.kt                 circle/box drawing, move, resize
        CaptureService.kt                MediaProjection foreground service
        CircleAccessibilityService.kt    shortcut detection
        CaptureCoordinator.kt            capture -> open selection
        LensLauncher.kt                  Google Lens intent + share fallback
        ImageCropper.kt                  crop + JPEG save
        TempFiles.kt                     temp file handling and cleanup
        Permissions.kt                   permission checks
        Prefs.kt                         settings storage
      res/
        layout/ activity_main, activity_settings, activity_selection
        values/ strings, colors, themes
        xml/ accessibility_service_config, file_paths
        drawable/ icons and backgrounds
        mipmap-anydpi-v26/ launcher icon
```

## Build

### Option A: Android Studio (PC)
1. Install Android Studio (current stable).
2. File > Open > choose the `CircleSearch` folder. Wait for "Gradle sync" to finish (it downloads Gradle 8.7 and the SDK pieces).
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. The file is `app/build/outputs/apk/debug/app-debug.apk`.

### Option B: GitHub (works from a phone)
1. Create a free GitHub account and a new empty repository.
2. Upload every file of this project (keep the folder structure, including the hidden `.github` folder).
3. Open the repository > Actions > "Build APK" > Run workflow.
4. When it is green, open the run and download the artifact `CircleSearch-debug-apk` (a zip with `app-debug.apk`).

## Install on the Vivo Y03t
1. Copy `app-debug.apk` to the phone and tap it.
2. If asked, allow "Install unknown apps" for the app you used to open the file (Files, Chrome...).
3. If Vivo shows a security scan screen, continue / "Install anyway".

## First-time setup (in this order)
1. Open CircleSearch. Tap **Allow restricted settings (App info)**.
   In the App info screen tap the 3-dot menu (top right) > **Allow restricted settings**.
   (Android 13+ blocks accessibility for APKs installed outside the Play Store until you do this. If you do not see the menu item, skip this step and see if the next step works.)
2. Back in the app tap **Open Accessibility settings** > find **CircleSearch** (often under "Downloaded apps" / "Installed services") > turn it ON > confirm.
   The service cannot read your screen. Its description says so.
3. Tap **Start CircleSearch** > allow notifications > in the system dialog choose **Entire screen** > **Start now**.
4. Test: tap **Try it (3-second delay)**, or hold Volume Down for about 0.7 seconds on any screen.
5. Optional: set up the accessibility shortcut: Settings > Accessibility > (Accessibility) shortcut / button > choose CircleSearch.
   Menu names differ slightly on Funtouch OS.

## Troubleshooting for Vivo (Funtouch OS)
Vivo is aggressive about killing background apps. If the shortcut stops working or the session ends:
- Settings > Battery > Background power consumption management > CircleSearch > **Allow high background power consumption**.
- Settings > Apps > Autostart (or i Manager > App management > Autostart) > turn ON for CircleSearch.
- Settings > Apps > App management > CircleSearch > Battery > choose **Unrestricted / Allow background activity**.
- Open the recent-apps screen, long-press the CircleSearch card (or tap its menu) and choose **Lock**, so "clear all" does not kill it.
- Do not use "Clear all" in the recent-apps screen or phone-manager "Boost / Clean" tools while a session runs.
- If the accessibility service switches itself off: re-enable it, then repeat the battery steps above.
- If nothing happens when you hold the volume key: make sure a session is running (green "Active" on the main screen) and the accessibility service is ON.
- If the selection screen does not appear after the screenshot: Settings > Apps > CircleSearch > Permissions / Other permissions and allow
  "Display pop-up windows while running in the background" (Vivo wording) and "Start in background" if present.
- If Lens does nothing: Settings inside CircleSearch > turn on "Always use the share sheet".
- If you see a black screenshot: the current app blocks screenshots.

## Privacy
- No INTERNET permission, no login, no analytics, no servers of ours.
- Screenshots and crops are stored only in the private cache folder and deleted after use.
- The accessibility service declares no window-content access and no event types.
- The only data that leaves the phone is the crop you choose to send to Google Lens / another app via the share action.
